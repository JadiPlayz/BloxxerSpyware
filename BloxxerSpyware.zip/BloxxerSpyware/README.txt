This was made to test error message mechanics.

Dont think its just some malicious program.

I just wanted to do this.

This isnt a spyware.